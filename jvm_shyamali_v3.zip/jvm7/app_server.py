#!/usr/bin/env python3
"""JVM Shyamali local server with role-based auth and SQLite persistence.

Run with: python app_server.py
This is a secure-by-default local/demo server, not a substitute for HTTPS and
an institution-managed production deployment.
"""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import hashlib
from concurrent.futures import ThreadPoolExecutor
import hmac
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent
PRIVATE = ROOT / "private_data"
DB_PATH = PRIVATE / "school.sqlite3"
STUDENTS_SEED = PRIVATE / "seed_students.json"
TEACHERS_SEED = PRIVATE / "seed_teachers.json"
MASTER_SEED = PRIVATE / "seed_master.json"
SESSION_COOKIE = "jvm_session"
PBKDF2_ROUNDS = 260_000
SESSIONS: dict[str, dict] = {}
LOGIN_ATTEMPTS: dict[str, list[float]] = {}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def db_conn():
    con = sqlite3.connect(DB_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con

@contextmanager
def connection():
    con = db_conn()
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def password_hash(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    hashed = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)
    return salt.hex(), hashed.hex()


def password_matches(password: str, salt_hex: str, hash_hex: str) -> bool:
    try:
        _, candidate = password_hash(password, bytes.fromhex(salt_hex))
        return hmac.compare_digest(candidate, hash_hex)
    except (ValueError, TypeError):
        return False


def sanitize_student(student: dict) -> dict:
    return {k: v for k, v in student.items() if k not in {"password", "parentPassword", "passwordHash", "parentPasswordHash"}}


def teacher_assignment(teacher: dict, students: dict[str, dict]) -> tuple[set[str], str]:
    """Resolve least-privilege academic or activity-only scope from supplied faculty assignments."""
    academic_scope = class_scope_for_teacher(teacher, students)
    if academic_scope:
        return academic_scope, "academic"
    department = str(teacher.get("department", "")).lower()
    subject_text = " ".join(str(s.get("classes", "")) for s in teacher.get("subjects", []) if isinstance(s, dict)).lower()
    all_ids = set(students)
    if "physical education" in department and "all sections" in subject_text:
        return all_ids, "extracurricular"
    if "fine arts" in department and ("primary, middle & secondary" in subject_text or "primary, middle and secondary" in subject_text):
        scope = {sid for sid, rec in students.items()
                 if not re.search(r"\bclass\s+(11|12)\b", str(rec.get("cls", "")), re.I)}
        return scope, "extracurricular"
    if "music" in department and "all wings" in subject_text:
        return all_ids, "extracurricular"
    return set(), "unassigned"


def student_view_for_role(student: dict, role: str, teacher_mode: str = "academic") -> dict:
    """Project each record to the minimum fields that role's UI needs."""
    clean = sanitize_student(student)
    if role == "teacher":
        if teacher_mode == "extracurricular":
            fields = {"id", "name", "avatar", "cls", "sec", "roll", "house", "extracurricular"}
        else:
            fields = {"id", "name", "avatar", "cls", "sec", "roll", "house", "attendance",
                      "academics", "discipline", "remarks", "classTeacher", "classTeacherId"}
        return {k: clean[k] for k in fields if k in clean}
    if role in {"student", "parent"}:
        # A linked family account does not need the parent login alias from the record.
        clean.pop("parentId", None)
    return clean


def seed_database_if_needed() -> None:
    PRIVATE.mkdir(parents=True, exist_ok=True)
    if not all(p.exists() for p in (STUDENTS_SEED, TEACHERS_SEED, MASTER_SEED)):
        raise RuntimeError("Private seed files are missing; refusing to start with an empty or partial database.")
    students = json.loads(STUDENTS_SEED.read_text(encoding="utf-8"))
    teachers = json.loads(TEACHERS_SEED.read_text(encoding="utf-8"))
    master = json.loads(MASTER_SEED.read_text(encoding="utf-8"))
    con = db_conn()
    try:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS records (
            student_id TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS users (
            role TEXT NOT NULL,
            login_id TEXT NOT NULL,
            salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            student_id TEXT,
            metadata TEXT NOT NULL DEFAULT '{}',
            aliases TEXT NOT NULL DEFAULT '[]',
            PRIMARY KEY (role, login_id)
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            occurred_at TEXT NOT NULL,
            actor_role TEXT NOT NULL,
            actor_id TEXT NOT NULL,
            action TEXT NOT NULL,
            student_id TEXT,
            changed_fields TEXT NOT NULL DEFAULT '[]'
        );
        CREATE TABLE IF NOT EXISTS enquiries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            message TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'new'
        );
        CREATE INDEX IF NOT EXISTS idx_records_class ON records(json_extract(payload, '$.cls'));
        CREATE INDEX IF NOT EXISTS idx_audit_date ON audit_log(occurred_at);
        """)
        count = con.execute("SELECT COUNT(*) FROM records").fetchone()[0]
        if count == 0:
            for sid, record in students.items():
                con.execute("INSERT INTO records(student_id,payload,updated_at) VALUES(?,?,?)",
                            (sid, json.dumps(sanitize_student(record), ensure_ascii=False), utc_now()))
        user_count = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if user_count == 0:
            # Prepare the seed accounts in memory, hash in worker threads, then write
            # everything in one transaction. This preserves modern password hashing
            # while making the initial setup much quicker and preventing partial seeds.
            pending = []
            def queue_user(role, login_id, password, student_id=None, metadata=None, aliases=None):
                salt = secrets.token_bytes(16)
                pending.append((role, login_id.strip().upper(), password, salt.hex(), student_id,
                                json.dumps(metadata or {}, ensure_ascii=False),
                                json.dumps([str(a).strip().upper() for a in (aliases or []) if a]), salt))
            queue_user("master", master["id"], master["password"], metadata={"displayName": master.get("displayName", "Master Administrator")})
            for teacher in teachers:
                queue_user("teacher", teacher["id"], teacher["password"], metadata={
                    "id": teacher["id"], "name": teacher.get("name", "Faculty"),
                    "department": teacher.get("department", ""),
                    "classTeacherOf": teacher.get("classTeacherOf", ""),
                    "teacher": sanitize_student(teacher),
                })
            for sid, record in students.items():
                queue_user("student", sid, record["password"], student_id=sid,
                           metadata={"name": record.get("name", "Student")}, aliases=[record.get("regNo", "")])
                queue_user("parent", record["parentId"], record["parentPassword"], student_id=sid,
                           metadata={"name": record.get("parents", {}).get("father", "Parent")}, aliases=[sid])
            def hash_pending(item):
                role, login_id, password, salt_hex, student_id, metadata, aliases, salt = item
                hashed = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS).hex()
                return (role, login_id, salt_hex, hashed, student_id, metadata, aliases)
            worker_count = min(8, max(2, os.cpu_count() or 2))
            with ThreadPoolExecutor(max_workers=worker_count) as pool:
                hashed_users = list(pool.map(hash_pending, pending))
            con.executemany("INSERT INTO users(role,login_id,salt,password_hash,student_id,metadata,aliases) VALUES(?,?,?,?,?,?,?)", hashed_users)
        con.commit()
        expected = len(students)
        actual = con.execute("SELECT COUNT(*) FROM records").fetchone()[0]
        if actual != expected:
            raise RuntimeError(f"Student record count mismatch: seed={expected}, database={actual}; refusing to continue.")
        expected_users = 1 + len(teachers) + (2 * len(students))
        actual_users = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if actual_users != expected_users:
            raise RuntimeError(f"Account count mismatch: expected {expected_users}, database={actual_users}; refusing to continue.")
    finally:
        con.close()


def class_scope_for_teacher(teacher: dict, students: dict[str, dict]) -> set[str]:
    """Return explicit student IDs assigned by class/section; broad 'all' scopes are not accepted."""
    phrases: list[str] = []
    class_teacher_of = str(teacher.get("classTeacherOf", ""))
    if class_teacher_of:
        phrases.append(class_teacher_of)
    for subject in teacher.get("subjects", []) or []:
        phrase = subject.get("classes", "") if isinstance(subject, dict) else ""
        if phrase:
            phrases.extend(x.strip() for x in str(phrase).split(",") if x.strip())
    # Teacher metadata may itself include a sanitized copy of the full teacher object.
    allowed: set[str] = set()
    class_names = sorted({str(s.get("cls", "")) for s in students.values()}, key=len, reverse=True)
    for phrase in phrases:
        lower = phrase.lower().strip()
        if not lower or "all section" in lower or "all wing" in lower or "primary, middle" in lower:
            continue
        for class_name in class_names:
            pattern = r"(?<![a-z0-9])" + re.escape(class_name.lower()) + r"(?![a-z0-9])"
            if not re.search(pattern, lower):
                continue
            # Match section only when the assignment specifies one.
            wanted_section = None
            sm = re.search(r"section\s+([a-z])\b", lower)
            if sm:
                wanted_section = sm.group(1).upper()
            else:
                # Common compact notation such as Class 10-A / Class 9-A.
                compact = re.search(re.escape(class_name.lower()) + r"\s*-\s*([a-z])\b", lower)
                if compact:
                    wanted_section = compact.group(1).upper()
            for sid, record in students.items():
                if record.get("cls") != class_name:
                    continue
                sec = str(record.get("sec", ""))
                if wanted_section and not re.search(r"\b" + re.escape(wanted_section) + r"\b", sec, re.I):
                    continue
                # If a teacher explicitly lists a special track (e.g. Rose Section), enforce it.
                special = re.search(r"(rose|lotus)\s+section", lower)
                if special and special.group(1).lower() not in sec.lower():
                    continue
                # If the class label includes a track suffix, match it exactly when identifiable.
                for track in ("pcm + computer science", "pcb + biotechnology", "accountancy & economics",
                              "accountancy & business studies", "liberal arts & economics"):
                    if track in lower and track not in sec.lower():
                        break
                else:
                    allowed.add(sid)
    return allowed


def get_record_map(con) -> dict[str, dict]:
    return {r["student_id"]: json.loads(r["payload"]) for r in con.execute("SELECT student_id,payload FROM records")}


def allowed_ids_for_session(con, sess: dict) -> set[str]:
    role = sess.get("role")
    if role == "master":
        return {r[0] for r in con.execute("SELECT student_id FROM records")}
    if role in ("student", "parent"):
        return {sess["student_id"]} if sess.get("student_id") else set()
    if role == "teacher":
        data = json.loads(sess.get("teacher_json", "{}"))
        scope, mode = teacher_assignment(data, get_record_map(con))
        if mode != sess.get("teacher_mode", "unassigned"):
            return set()  # Fail closed if an in-memory role assignment is inconsistent.
        return scope
    return set()


def records_for_session(con, sess: dict) -> dict[str, dict]:
    allowed = allowed_ids_for_session(con, sess)
    out = {}
    for sid in sorted(allowed):
        row = con.execute("SELECT payload FROM records WHERE student_id=?", (sid,)).fetchone()
        if row:
            out[sid] = student_view_for_role(json.loads(row[0]), sess.get("role", ""), sess.get("teacher_mode", "academic"))
    return out


def public_session(sess: dict) -> dict:
    out = {k: v for k, v in sess.items() if k not in {"teacher_json", "password", "salt", "password_hash"}}
    return out


def seed_record_map() -> dict[str, dict]:
    return json.loads(STUDENTS_SEED.read_text(encoding="utf-8"))



# ---------------------------------------------------------------- chatbot
CHAT_HITS: dict = {}
SITE_LINKS = [
    (r"fee|tuition|payment|scholarship", "Fee structure & calculator", "/pages/admissions.html#fees", "Here is the fee structure and calculator for all classes."),
    (r"timetable|time table|schedule|period|routine", "Class timetables", "/pages/academics.html#timetable", "Pick a class and a day to see its timetable."),
    (r"calendar|holiday|event|vacation|ptm|exam date", "Academic calendar", "/pages/academics.html#calendar", "The academic calendar lists holidays, exams and events."),
    (r"admission|apply|enrol|registration|faq", "Admissions & FAQs", "/pages/admissions.html#faq", "Admission details and common questions are here."),
    (r"topper|result|rank|achievement|news|notice|circular", "News, toppers & notices", "/pages/news.html#news", "Latest notices, results and toppers are here."),
    (r"teacher|faculty|staff|principal", "Our faculty", "/pages/campus.html#faculty", "Meet our faculty here."),
    (r"gallery|photo|picture", "Photo gallery", "/pages/campus.html#gallery", "Take a look at campus life."),
    (r"campus|facilit|library|sports|about|history", "About & campus", "/pages/campus.html#campus", "Learn about the school and its campus."),
    (r"contact|phone|address|email|enquir|location|reach", "Contact the school", "/pages/contact.html", "You can send an enquiry from the contact page."),
    (r"login|portal|sign in|dashboard|parent portal", "Portals (sign in)", "/pages/portal.html", "Sign in to your portal here."),
]
STOP = set("find search show open get give me the a an of for to go link student students dashboard profile record records please class section is are with and".split())
AI_SYSTEM = ("You are the website assistant for Jawahar Vidya Mandir, Shyamali, Ranchi. Reply in at most four short sentences. "
             "Never invent fees, dates, results, notices or contact details; if unsure, say so and point to the relevant page or the school office. "
             "You have no access to student records. Pages: fees /pages/admissions.html#fees, timetable /pages/academics.html#timetable, "
             "calendar /pages/academics.html#calendar, news /pages/news.html, faculty /pages/campus.html#faculty, contact /pages/contact.html, portals /pages/portal.html.")

def _ai_text(message: str):
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if key:
        try:
            req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps({
                "model": os.environ.get("JVM_AI_MODEL", "claude-sonnet-5-5"), "max_tokens": 400, "system": AI_SYSTEM,
                "messages": [{"role": "user", "content": message}]}).encode(),
                headers={"content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"})
            with urllib.request.urlopen(req, timeout=25) as r:
                data = json.load(r)
            text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
            if text: return text
        except Exception:
            pass
    model = os.environ.get("JVM_OLLAMA_MODEL", "").strip()
    if model:
        try:
            req = urllib.request.Request("http://127.0.0.1:11434/api/chat", data=json.dumps({"model": model, "stream": False,
                "messages": [{"role": "system", "content": AI_SYSTEM}, {"role": "user", "content": message}]}).encode(),
                headers={"content-type": "application/json"})
            with urllib.request.urlopen(req, timeout=60) as r:
                text = (json.load(r).get("message", {}).get("content") or "").strip()
            if text: return text
        except Exception:
            pass
    return None

def chat_reply(sess, message: str) -> dict:
    from urllib.parse import quote
    msg = message.strip()[:400]
    low = msg.lower()
    if not msg:
        return {"reply": "Ask me about fees, timetables, the calendar, admissions, faculty \u2014 or search for a student by name if you are signed in as faculty.", "links": []}
    role = (sess or {}).get("role", "")
    wants_student = bool(re.search(r"student|dashboard|marks|attendance|record|find|search|show|open", low))
    link_hits = [(label, url, text) for rx, label, url, text in SITE_LINKS if re.search(rx, low)]
    tokens = [t for t in re.findall(r"[a-z0-9/]+", low) if t not in STOP and len(t) > 1]
    if role in ("teacher", "master") and tokens and (wants_student or not link_hits):
        with connection() as con:
            records = records_for_session(con, sess)
        hits = [r for r in records.values() if all(t in (str(r.get("name", "")) + " " + str(r.get("id", "")) + " " + str(r.get("cls", "")) + " " + str(r.get("sec", ""))).lower() for t in tokens)]
        if hits:
            hits.sort(key=lambda r: (str(r.get("cls")), int(r.get("roll") or 0)))
            links = [{"label": f"{r['name']} \u2014 {r['cls']} ({r['id']})", "url": "/pages/portal.html?student=" + quote(str(r["id"]), safe="")} for r in hits[:6]]
            more = f" (showing the first 6 of {len(hits)})" if len(hits) > 6 else ""
            return {"reply": f"I found {len(hits)} matching student(s){more}. Tap a name to open the dashboard.", "links": links}
    if role in ("student", "parent") and re.search(r"my|dashboard|marks|attendance|result|record", low):
        return {"reply": "Here is your dashboard.", "links": [{"label": "Open my dashboard", "url": "/pages/portal.html"}]}
    if not role and wants_student and re.search(r"student|dashboard|marks|attendance", low):
        return {"reply": "Student dashboards are private. Please sign in to the portal first (faculty can then search any student by name here).", "links": [{"label": "Portals (sign in)", "url": "/pages/portal.html"}]}
    links = [{"label": l, "url": u} for l, u, _ in link_hits[:3]]
    ai = _ai_text(msg)
    if ai: return {"reply": ai, "links": links, "ai": True}
    if link_hits: return {"reply": link_hits[0][2], "links": links}
    return {"reply": "I can help with fees, timetables, the calendar, admissions, faculty and contact details. (Free-form AI answers are switched off until an AI key or local model is configured \u2014 see README.)", "links": [{"label": "Fee structure", "url": "/pages/admissions.html#fees"}, {"label": "Timetables", "url": "/pages/academics.html#timetable"}]}

class Handler(BaseHTTPRequestHandler):
    server_version = "JVMPortal/1.0"

    def log_message(self, fmt, *args):
        # Keep request logging, but never log request bodies, credentials, or cookies.
        super().log_message(fmt, *args)

    def _headers(self, status=200, content_type="application/json; charset=utf-8", length=None, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Cache-Control", "no-store" if self.path.startswith("/api/") else "no-cache")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if length is not None:
            self.send_header("Content-Length", str(length))
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()

    def _json(self, value, status=200, extra=None):
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self._headers(status, length=len(data), extra=extra)
        self.wfile.write(data)

    def _body(self, limit=1_500_000):
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            size = 0
        if size < 0 or size > limit:
            raise ValueError("Request body is too large.")
        raw = self.rfile.read(size) if size else b"{}"
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("Request must contain valid JSON.")
        if not isinstance(data, dict):
            raise ValueError("JSON body must be an object.")
        return data

    def _host_origin_ok(self) -> bool:
        origin = self.headers.get("Origin")
        if not origin:
            return True  # same-origin navigations and command-line tests
        parsed = urlparse(origin)
        host = self.headers.get("Host", "")
        return parsed.netloc.lower() == host.lower() and parsed.scheme in ("http", "https")

    def _cookie_session(self):
        token = None
        for part in self.headers.get("Cookie", "").split(";"):
            k, sep, v = part.strip().partition("=")
            if sep and k == SESSION_COOKIE:
                token = v
                break
        sess = SESSIONS.get(token) if token else None
        if sess and time.time() - sess.get("created_epoch", 0) > 8 * 60 * 60:
            SESSIONS.pop(token, None)
            return None, token
        return sess, token

    def _require_session(self):
        sess, token = self._cookie_session()
        if not sess:
            self._json({"error": "Please sign in again."}, 401)
            return None
        return sess

    def _log(self, con, sess, action, student_id=None, fields=None):
        con.execute("INSERT INTO audit_log(occurred_at,actor_role,actor_id,action,student_id,changed_fields) VALUES(?,?,?,?,?,?)",
                    (utc_now(), sess.get("role", "system"), sess.get("id", "system"), action,
                     student_id, json.dumps(fields or [])))

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        if path == "/api/me":
            sess, _ = self._cookie_session()
            if not sess:
                self._json({"error": "Not signed in."}, 401)
                return
            with connection() as con:
                records = records_for_session(con, sess)
            self._json({"user": public_session(sess), "records": records})
            return
        if path == "/api/students":
            sess = self._require_session()
            if not sess: return
            with connection() as con:
                records = records_for_session(con, sess)
            self._json({"records": records})
            return
        if path == "/api/enquiries":
            sess = self._require_session()
            if not sess: return
            if sess.get("role") != "master":
                self._json({"error": "Master access required."}, 403)
                return
            with connection() as con:
                rows = con.execute("SELECT id,created_at,name,email,message,status FROM enquiries ORDER BY id DESC LIMIT 300").fetchall()
            self._json({"enquiries": [dict(r) for r in rows]})
            return
        if path == "/api/audit":
            sess = self._require_session()
            if not sess: return
            if sess.get("role") != "master":
                self._json({"error": "Master access required."}, 403)
                return
            with connection() as con:
                rows = con.execute("SELECT id,occurred_at,actor_role,actor_id,action,student_id,changed_fields FROM audit_log ORDER BY id DESC LIMIT 500").fetchall()
            events = []
            for row in rows:
                event = dict(row)
                try:
                    event["changed_fields"] = json.loads(event.get("changed_fields") or "[]")
                except (TypeError, json.JSONDecodeError):
                    event["changed_fields"] = []
                events.append(event)
            self._json({"events": events})
            return
        if path.startswith("/images/"):
            img = (ROOT / "images" / path[len("/images/"):]).resolve()
            if (ROOT / "images").resolve() in img.parents and img.is_file() and img.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg"):
                data = img.read_bytes(); self._headers(200, mimetypes.guess_type(img.name)[0] or "application/octet-stream", length=len(data)); self.wfile.write(data); return
            self._json({"error": "Not found."}, 404); return
        # Explicit public-file allowlist. Private JSON, the source backup HTML, SQLite DB,
        # seed data and any unknown paths are never served as static files.
        allowed_files = {
            "/", "/index.html", "/pages/index.html", "/pages/academics.html",
            "/pages/campus.html", "/pages/news.html", "/pages/portal.html",
            "/pages/contact.html", "/pages/admissions.html", "/achievements.json",
            "/faculty.json", "/timetable.json", "/section-roster.json", "/official-sources.json",
        }
        if path not in allowed_files:
            self._json({"error": "Not found."}, 404)
            return
        actual = ROOT / ("index.html" if path == "/" else path.lstrip("/"))
        if not actual.is_file() or PRIVATE in actual.parents:
            self._json({"error": "Not found."}, 404)
            return
        try:
            data = actual.read_bytes()
        except OSError:
            self._json({"error": "Unable to read page."}, 500)
            return
        content_type = mimetypes.guess_type(actual.name)[0] or "application/octet-stream"
        if content_type == "text/html": content_type += "; charset=utf-8"
        if content_type == "application/json": content_type += "; charset=utf-8"
        self._headers(200, content_type, length=len(data))
        self.wfile.write(data)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        if not self._host_origin_ok():
            self._json({"error": "Cross-origin request rejected."}, 403)
            return
        try:
            body = self._body()
        except ValueError as exc:
            self._json({"error": str(exc)}, 400)
            return
        if path == "/api/login":
            ip = self.client_address[0]
            now = time.time()
            LOGIN_ATTEMPTS[ip] = [t for t in LOGIN_ATTEMPTS.get(ip, []) if now - t < 60]
            if len(LOGIN_ATTEMPTS[ip]) >= 12:
                self._json({"error": "Too many login attempts. Please wait a minute."}, 429)
                return
            role = str(body.get("role", "")).strip().lower()
            if role == "admin": role = "master"
            supplied_id = str(body.get("id", "")).strip().upper()
            password = str(body.get("password", ""))
            if role not in {"student", "parent", "teacher", "master"} or not supplied_id or not password:
                self._json({"error": "Invalid role or credentials."}, 400)
                return
            with connection() as con:
                candidates = con.execute("SELECT * FROM users WHERE role=?", (role,)).fetchall()
                user = None
                for candidate in candidates:
                    aliases = json.loads(candidate["aliases"] or "[]")
                    if candidate["login_id"] == supplied_id or supplied_id in aliases:
                        user = candidate
                        break
                if not user or not password_matches(password, user["salt"], user["password_hash"]):
                    LOGIN_ATTEMPTS[ip].append(now)
                    self._json({"error": "Invalid credentials for the selected role."}, 401)
                    return
                LOGIN_ATTEMPTS[ip] = []
                metadata = json.loads(user["metadata"] or "{}")
                session_id = secrets.token_urlsafe(32)
                sess = {"role": role, "id": user["login_id"], "created_epoch": now,
                        "student_id": user["student_id"]}
                if role == "master":
                    sess["displayName"] = metadata.get("displayName", "Master Administrator")
                elif role == "teacher":
                    sess["id"] = metadata.get("id", user["login_id"])
                    sess["name"] = metadata.get("name", "Faculty")
                    sess["department"] = metadata.get("department", "")
                    sess["classTeacherOf"] = metadata.get("classTeacherOf", "")
                    teacher_data = metadata.get("teacher", {})
                    sess["teacher_json"] = json.dumps(teacher_data, ensure_ascii=False)
                    _, sess["teacher_mode"] = teacher_assignment(teacher_data, get_record_map(con))
                elif role == "student":
                    sess["name"] = metadata.get("name", "Student")
                elif role == "parent":
                    sess["studentId"] = user["student_id"]
                    sess["studentName"] = metadata.get("name", "Parent")
                SESSIONS[session_id] = sess
                self._log(con, sess, "login")
                con.commit()
                records = records_for_session(con, sess)
            cookie = f"{SESSION_COOKIE}={session_id}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800"
            if self.headers.get("X-Forwarded-Proto", "").lower() == "https": cookie += "; Secure"
            self._json({"user": public_session(sess), "records": records}, 200, {"Set-Cookie": cookie})
            return
        if path == "/api/logout":
            sess, token = self._cookie_session()
            if token: SESSIONS.pop(token, None)
            extra = {"Set-Cookie": f"{SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"}
            self._json({"ok": True}, 200, extra)
            return
        if path == "/api/chat":
            ip = self.client_address[0]; now = time.time()
            CHAT_HITS[ip] = [t for t in CHAT_HITS.get(ip, []) if now - t < 60]
            if len(CHAT_HITS[ip]) >= 30:
                self._json({"error": "Too many messages. Please wait a minute."}, 429); return
            CHAT_HITS[ip].append(now)
            sess, _token = self._cookie_session()
            self._json(chat_reply(sess, str(body.get("message", ""))))
            return
        if path == "/api/contact":
            name = str(body.get("name", "")).strip()
            email = str(body.get("email", "")).strip()
            message = str(body.get("message", "")).strip()
            if not name or len(name) > 120 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email) or len(email) > 254 or not message or len(message) > 5000:
                self._json({"error": "Please provide a valid name, email and message (maximum 5000 characters)."}, 400)
                return
            with connection() as con:
                cur = con.execute("INSERT INTO enquiries(created_at,name,email,message) VALUES(?,?,?,?)",
                                  (utc_now(), name, email, message))
                enquiry_id = cur.lastrowid
                con.commit()
            self._json({"ok": True, "id": enquiry_id, "message": "Inquiry saved on this server. This form does not email the school."}, 201)
            return
        if path == "/api/admin/import-legacy":
            sess = self._require_session()
            if not sess: return
            if sess.get("role") != "master":
                self._json({"error": "Master access required."}, 403)
                return
            legacy = body.get("records")
            if not isinstance(legacy, dict):
                self._json({"error": "No legacy records supplied."}, 400)
                return
            seed = seed_record_map()
            changes = 0
            skipped_records = 0
            skipped_fields = 0
            immutable = {"id", "regNo", "password", "parentPassword", "passwordHash", "parentPasswordHash"}
            with connection() as con:
                for sid, old_record in legacy.items():
                    if sid not in seed or not isinstance(old_record, dict):
                        skipped_records += 1
                        continue
                    clean = sanitize_student(old_record)
                    baseline = sanitize_student(seed[sid])
                    changed = {}
                    for key, value in clean.items():
                        if key in immutable:
                            continue
                        if key not in baseline:
                            skipped_fields += 1
                            continue
                        if value != baseline[key]:
                            changed[key] = value
                    row = con.execute("SELECT payload FROM records WHERE student_id=?", (sid,)).fetchone()
                    if not row:
                        skipped_records += 1
                        continue
                    if changed:
                        current = json.loads(row[0])
                        current.update(changed)
                        con.execute("UPDATE records SET payload=?,updated_at=? WHERE student_id=?",
                                    (json.dumps(sanitize_student(current), ensure_ascii=False), utc_now(), sid))
                        self._log(con, sess, "legacy-localstorage-import", sid, list(changed.keys()))
                        changes += 1
                con.commit()
                records = records_for_session(con, sess)
            self._json({"ok": True, "changed_records": changes, "skipped_records": skipped_records,
                        "skipped_fields": skipped_fields, "records": records})
            return
        self._json({"error": "Not found."}, 404)

    def do_PATCH(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if not self._host_origin_ok():
            self._json({"error": "Cross-origin request rejected."}, 403)
            return
        sess = self._require_session()
        if not sess: return
        if path != "/api/student-record":
            self._json({"error": "Not found."}, 404)
            return
        sid = parse_qs(parsed.query).get("student_id", [""])[0]
        if not sid or len(sid) > 120:
            self._json({"error": "Invalid student identifier."}, 400)
            return
        if sess.get("role") not in {"teacher", "master"}:
            self._json({"error": "Read-only role. Student and parent accounts cannot modify records."}, 403)
            return
        try:
            patch = self._body(limit=200_000)
        except ValueError as exc:
            self._json({"error": str(exc)}, 400)
            return
        if not patch or not isinstance(patch, dict):
            self._json({"error": "No changes supplied."}, 400)
            return
        if sess.get("role") == "teacher":
            if sess.get("teacher_mode") == "extracurricular":
                forbidden = set(patch) - {"extracurricular"}
                denial = "Activity faculty may edit extracurricular activities only."
            else:
                forbidden = set(patch) - {"academics", "attendance", "remarks"}
                denial = "Academic teachers may edit marks, attendance and remarks only."
            if forbidden:
                self._json({"error": denial}, 403)
                return
        allowed_fields = {"academics", "attendance", "remarks", "parents", "fees", "discipline", "extracurricular", "house", "room", "classTeacher", "sec", "cls", "roll"}
        if set(patch) - allowed_fields:
            self._json({"error": "One or more fields cannot be edited."}, 400)
            return
        with connection() as con:
            row = con.execute("SELECT payload FROM records WHERE student_id=?", (sid,)).fetchone()
            if not row:
                self._json({"error": "Student record not found."}, 404)
                return
            scope = allowed_ids_for_session(con, sess)
            if sid not in scope:
                self._json({"error": "This account is not assigned to that student."}, 403)
                return
            record = json.loads(row[0])
            if "academics" in patch:
                academics = patch["academics"]
                if not isinstance(academics, dict):
                    self._json({"error": "Academic data must be an object."}, 400); return
                marks = academics.get("marks", record.get("academics", {}).get("marks", []))
                if not isinstance(marks, list) or len(marks) > 40:
                    self._json({"error": "Invalid marks list."}, 400); return
                for mark in marks:
                    if not isinstance(mark, dict):
                        self._json({"error": "Invalid mark entry."}, 400); return
                    try: obtained, maximum = float(mark.get("m", 0)), float(mark.get("total", 100))
                    except (ValueError, TypeError):
                        self._json({"error": "Marks must be numeric."}, 400); return
                    if maximum <= 0 or obtained < 0 or obtained > maximum:
                        self._json({"error": "Marks must stay between zero and the maximum marks."}, 400); return
                patch["academics"] = academics
            if "attendance" in patch:
                attendance = patch["attendance"]
                if not isinstance(attendance, dict):
                    self._json({"error": "Attendance data must be an object."}, 400); return
                try: present, total = int(attendance.get("present")), int(attendance.get("total"))
                except (ValueError, TypeError):
                    self._json({"error": "Attendance must use whole numbers."}, 400); return
                if total <= 0 or present < 0 or present > total or total > 400:
                    self._json({"error": "Attendance requires 0 ≤ present ≤ total ≤ 400 and total above zero."}, 400); return
                attendance["rate"] = f"{present / total * 100:.1f}%"
                patch["attendance"] = attendance
            if "remarks" in patch and (not isinstance(patch["remarks"], str) or len(patch["remarks"]) > 3000):
                self._json({"error": "Remarks must be text of at most 3000 characters."}, 400); return
            if "extracurricular" in patch:
                activities = patch["extracurricular"]
                if not isinstance(activities, list) or len(activities) > 30 or any(not isinstance(x, str) or len(x) > 250 for x in activities):
                    self._json({"error": "Extracurricular activities must be a list of up to 30 text items (250 characters each)."}, 400); return
                patch["extracurricular"] = [x.strip() for x in activities if x.strip()]
            for key, value in patch.items():
                if isinstance(value, dict) and isinstance(record.get(key), dict):
                    record[key].update(value)
                else:
                    record[key] = value
            record = sanitize_student(record)
            con.execute("UPDATE records SET payload=?,updated_at=? WHERE student_id=?",
                        (json.dumps(record, ensure_ascii=False), utc_now(), sid))
            self._log(con, sess, "student-record-update", sid, list(patch.keys()))
            con.commit()
        # Return only this authorized record; caller refreshes its own scoped copy.
        self._json({"ok": True, "record": student_view_for_role(record, sess.get("role", ""), sess.get("teacher_mode", "academic")), "committed_at": utc_now()})

    def do_OPTIONS(self):
        self._json({"error": "CORS is disabled. Use the same origin."}, 405)


def main():
    parser = argparse.ArgumentParser(description="JVM Shyamali website and secure record API")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Port (default: 8000)")
    args = parser.parse_args()
    seed_database_if_needed()
    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"JVM Shyamali website running at http://{args.host}:{args.port}")
    print(f"SQLite records are saved at {DB_PATH}; static file access uses an explicit allowlist.")
    print("Stop with Ctrl+C. Use HTTPS and rotate all demo credentials before deployment.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped. Saved records remain in SQLite.")
    finally:
        httpd.server_close()

if __name__ == "__main__":
    main()
